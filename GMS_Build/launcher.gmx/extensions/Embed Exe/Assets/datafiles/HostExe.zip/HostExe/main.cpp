#include "main.h"
#include <stdlib.h>
#include <string.h>
#include <direct.h>
#include <tchar.h>
#define DLL extern "C" _declspec(dllexport)

HANDLE handle=NULL;
HWND apphwnd;
HWND game;
HWND childhwnd;
RECT rect;
LPCTSTR clss="";
LPCTSTR ttl="";
HWND wnd=NULL;
INT exists;

HANDLE hProcess = NULL;
PROCESS_INFORMATION processInfo;
STARTUPINFO startupInfo;

LPCTSTR concat(LPCTSTR s1,LPCTSTR s2)
{
    char *result=(char *)malloc(strlen(s1)+strlen(s2)+1);
    strcpy(result,s1);
    strcat(result,s2);

    return result;
}

int CALLBACK EnumWindowsProc(HWND hwnd, LPARAM param)
{
DWORD pID;
DWORD TpID = GetWindowThreadProcessId(hwnd, &pID);
if (TpID == (DWORD)param)
{
apphwnd=hwnd;
return false;
}
return true;
}

HANDLE StartProcess(LPCTSTR program,LPCTSTR args)
{
     ::ZeroMemory(&startupInfo,sizeof(startupInfo));
     startupInfo.cb=sizeof(startupInfo);
     if(::CreateProcess(program,(LPTSTR)args,
                        NULL,
                        NULL,
                        FALSE,
                        0,
                        NULL,
                        NULL,
                        &startupInfo,
                        &processInfo))
        {
            WaitForInputIdle(processInfo.hProcess,INFINITE);
		 	::EnumWindows(&EnumWindowsProc,processInfo.dwThreadId);
	        hProcess=processInfo.hProcess;
        }
     return hProcess;
}

DLL double HostingStartEmbed(HWND game,char *Exe,char *Title,char *Class)
{
    exists=1;
    wnd=game;
    clss=Class;
    ttl=Title;

    if (handle!=NULL)
	{
	    TerminateProcess(handle,0);
	    if (hProcess!=NULL) WaitForSingleObject(hProcess,INFINITE);
	    handle=NULL;
	}

    GetClientRect(game,&rect);

    if (strstr(Exe,".swf")!=NULL)
    {
        char *path = NULL;
        path = getcwd(NULL, 0);

        LPTSTR szCmdline = _tcsdup(TEXT(Exe));
        handle=StartProcess(concat(path,"\\FlashObject.exe "),concat(" ",concat(path,concat("\\",szCmdline))));
        childhwnd=FindWindow("ShockwaveFlash","Flash Player -(+_+)-");
    }

    if (strstr(Exe,".swf")==NULL)
    {
        handle=StartProcess(Exe,"");
        childhwnd=FindWindow(clss,ttl);
    }

    if (childhwnd==NULL)
	{
        if(apphwnd!=NULL)
        {
            ::SetWindowLong(apphwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
            ::SetWindowLong(apphwnd, GWL_EXSTYLE, WS_EX_APPWINDOW|WS_EX_TOOLWINDOW);
            ::MoveWindow(apphwnd,rect.left,rect.top,rect.right,rect.bottom, true);
            ::SetParent(apphwnd,game);
            ::SetFocus(apphwnd);
        }
	}
	else
    {
        ::SetWindowLong(childhwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
        ::SetWindowLong(childhwnd, GWL_EXSTYLE, WS_EX_APPWINDOW|WS_EX_TOOLWINDOW);
        ::MoveWindow(childhwnd,rect.left,rect.top,rect.right,rect.bottom, true);
        ::SetParent(childhwnd,game);
        ::SetFocus(childhwnd);
    }

	return 0;
}

DLL double HostingStartEmbedLegacy(double WindowHandle,char *Exe,char *Title,char *Class)
{
    exists=1;
    wnd=(HWND)(DWORD)WindowHandle;
    clss=Class;
    ttl=Title;

    if (handle!=NULL)
	{
	    TerminateProcess(handle,0);
	    if (hProcess!=NULL) WaitForSingleObject(hProcess,INFINITE);
	    handle=NULL;
	}

    GetClientRect((HWND)(DWORD)WindowHandle,&rect);

    if (strstr(Exe,".swf")!=NULL)
    {
        char *path = NULL;
        path = getcwd(NULL, 0);

        LPTSTR szCmdline = _tcsdup(TEXT(Exe));
        handle=StartProcess(concat(path,"\\FlashObject.exe "),concat(" ",concat(path,concat("\\",szCmdline))));
        childhwnd=FindWindow("ShockwaveFlash","Flash Player -(+_+)-");
    }

    if (strstr(Exe,".swf")==NULL)
    {
        handle=StartProcess(Exe,"");
        childhwnd=FindWindow(clss,ttl);
    }

    if (childhwnd==NULL)
	{
        if(apphwnd!=NULL)
        {
            ::SetWindowLong(apphwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
            ::SetWindowLong(apphwnd, GWL_EXSTYLE, WS_EX_APPWINDOW|WS_EX_TOOLWINDOW);
            ::MoveWindow(apphwnd,rect.left,rect.top,rect.right,rect.bottom, true);
            ::SetParent(apphwnd,(HWND)(DWORD)WindowHandle);
            ::SetFocus(apphwnd);
        }
	}
	else
    {
        ::SetWindowLong(childhwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
        ::SetWindowLong(childhwnd, GWL_EXSTYLE, WS_EX_APPWINDOW|WS_EX_TOOLWINDOW);
        ::MoveWindow(childhwnd,rect.left,rect.top,rect.right,rect.bottom, true);
        ::SetParent(childhwnd,(HWND)(DWORD)WindowHandle);
        ::SetFocus(childhwnd);
    }

	return 0;
}

DLL double HostingEndEmbed()
{
    exists=0;
    if (handle!=NULL)
	{
	    TerminateProcess(handle,0);
	    if (hProcess!=NULL) WaitForSingleObject(hProcess,INFINITE);
	    handle=NULL;
	}
	return 0;
}

DLL double HostingCheckEmbed()
{
    if (exists==1)
    {
        if (IsWindow(apphwnd)==0&&IsWindow(childhwnd)==0)
        {
            exists=0;
        }
    }
    return exists;
}

DLL double HostingSetRectangle(double Left,double Top,double Right,double Bottom)
{
    if (exists==1)
    {
        if (childhwnd==NULL)
        {
            if (apphwnd!=NULL)
            {
                if (FindWindow(clss,ttl)!=NULL)
                {
                    if (childhwnd!=FindWindow("ShockwaveFlash","Flash Player -(+_+)-"))
                    {
                        childhwnd=FindWindow(clss,ttl);
                    }

                    ::SetWindowLong(childhwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
                    ::SetWindowLong(childhwnd, GWL_EXSTYLE, WS_EX_APPWINDOW|WS_EX_TOOLWINDOW);
                    ::MoveWindow(childhwnd,Left,Top,Right,Bottom,true);
                    ::SetFocus(childhwnd);
                }
                else
                {
                    ::SetWindowLong(apphwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
                    ::SetWindowLong(apphwnd, GWL_EXSTYLE, WS_EX_APPWINDOW|WS_EX_TOOLWINDOW);
                    ::MoveWindow(apphwnd,Left,Top,Right,Bottom,true);
                    ::SetFocus(apphwnd);
                }
            }
        }
        else
        {
            ::SetWindowLong(childhwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
            ::SetWindowLong(childhwnd, GWL_EXSTYLE, WS_EX_APPWINDOW|WS_EX_TOOLWINDOW);
            ::MoveWindow(childhwnd,Left,Top,Right,Bottom,true);
            ::SetFocus(childhwnd);
        }
    }

    return 0;
}
