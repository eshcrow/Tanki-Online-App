#include "main.h"
#define DLL extern "C" _declspec(dllexport)

HWND browser;
BOOL init=0;
BOOL init2=0;
INT efull=0;
DWORD gflags=0;
DWORD gexflags=0;
INT w=0;
INT h=0;

void SetToTop(HWND WindowHandle)
{
    if (IsIconic(WindowHandle)==0)
    {
        if (init==1)
        {
            init2=0;
            SetWindowPos(WindowHandle,HWND_NOTOPMOST,0,0,0,0,SWP_SHOWWINDOW|SWP_NOSIZE|SWP_NOMOVE);
        }
        else
        {
            if (init2==0)
            {
                SetWindowPos(WindowHandle,HWND_TOPMOST,0,0,0,0,SWP_SHOWWINDOW|SWP_NOSIZE|SWP_NOMOVE);
                init2=1;
            }
            SetForegroundWindow(WindowHandle);
        }
    }
}

void ClientResize(double hWnd, HWND game, double nWidth, double nHeight)
{
    RECT rcClient,rcWindow;
    POINT ptDiff;

    if ((HWND)(DWORD)hWnd!=NULL)
    {
        GetClientRect((HWND)(DWORD)hWnd, &rcClient);
        GetWindowRect((HWND)(DWORD)hWnd, &rcWindow);
        ptDiff.x=(rcWindow.right-rcWindow.left)-rcClient.right;
        ptDiff.y=(rcWindow.bottom-rcWindow.top)-rcClient.bottom;
        MoveWindow((HWND)(DWORD)hWnd,rcWindow.left,rcWindow.top,nWidth+ptDiff.x,nHeight+ptDiff.y,TRUE);
    }
    else
    {
        GetClientRect(game, &rcClient);
        GetWindowRect(game, &rcWindow);
        ptDiff.x=(rcWindow.right-rcWindow.left)-rcClient.right;
        ptDiff.y=(rcWindow.bottom-rcWindow.top)-rcClient.bottom;
        MoveWindow(game,rcWindow.left,rcWindow.top,nWidth+ptDiff.x,nHeight+ptDiff.y,TRUE);
    }
}

void GetFlags(double WindowHandle,HWND game,DWORD lflags, DWORD lexflags,double nWidth, double nHeight)
{
    if (lflags!=gflags)
    {
        lflags=gflags;
        init=0;
    }

    if (lexflags!=gexflags)
    {
        lexflags=gexflags;
        init=0;
    }

    if (init==0)
    {
        if (w==0&&h==0) ClientResize(WindowHandle,game,nWidth,nHeight);
        init=1;
    }
}

void BorderResize(double hWnd,HWND game)
{
    RECT rcClient,rcWindow;

    if ((HWND)(DWORD)hWnd!=NULL)
    {
        GetWindowRect((HWND)(DWORD)hWnd,&rcWindow);
        GetClientRect((HWND)(DWORD)hWnd,&rcClient);
        MoveWindow((HWND)(DWORD)hWnd,rcClient.left,rcClient.top,rcClient.right,rcClient.bottom,TRUE);
    }
    else
    {
        GetWindowRect(game,&rcWindow);
        GetClientRect(game,&rcClient);
        MoveWindow(game,rcWindow.left,rcWindow.top,rcClient.right,rcClient.bottom,TRUE);
    }
}

void EndFullscreen(double WindowHandle,HWND game)
{
    if (w!=0&&h!=0&&efull==1)
    {
        int x,y;
        x=(int)GetSystemMetrics(SM_CXSCREEN)/2-w/2;
        y=(int)GetSystemMetrics(SM_CYSCREEN)/2-h/2;
        if ((HWND)(DWORD)WindowHandle!=NULL)
        MoveWindow((HWND)(DWORD)WindowHandle,x,y,w,h,1);
        else
        MoveWindow(game,x,y,w,h,1);
        ClientResize(WindowHandle,game,w,h);
        efull=0;
        w=0;
        h=0;
    }
}


DLL double Borderless(double WindowHandle,HWND game,double Width, double Height)
{
    BorderResize(WindowHandle,game);

    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,0);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop((HWND)(DWORD)WindowHandle);
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,0);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop(game);
    }

    GetFlags(WindowHandle,game,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,0,Width,Height);
    EndFullscreen(WindowHandle,game);

	return 0;
}

DLL double DefaultStyle(double WindowHandle,HWND game,double Width, double Height)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,0);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_MINIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop((HWND)(DWORD)WindowHandle);
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,0);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_MINIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop(game);
    }

    GetFlags(WindowHandle,game,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_MINIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,0,Width,Height);
    EndFullscreen(WindowHandle,game);

	return 0;
}

DLL double FakeFullscreen(double WindowHandle,HWND game,double Width, double Height)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
    if (IsChild((HWND)(DWORD)WindowHandle,FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY")))
    {
        browser=FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY");
    }
    }
    else
    {
    if (IsChild(game,FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY")))
    {
        browser=FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY");
    }
    }

    efull=1;
    if (w==0&&h==0)
    {
        Borderless(WindowHandle,game,Width,Height);

        w=Width;
        h=Height;
    }
    else
    {
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,0);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        MoveWindow((HWND)(DWORD)WindowHandle,0,0,(int)GetSystemMetrics(SM_CXSCREEN), (int)GetSystemMetrics(SM_CYSCREEN),1);

        if (GetForegroundWindow()==(HWND)(DWORD)WindowHandle)
        {
            init=0;
            SetToTop((HWND)(DWORD)WindowHandle);
        }
        else
        {
            if (browser==NULL)
            {
                init=1;
                SetToTop((HWND)(DWORD)WindowHandle);
            }
        }
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,0);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        MoveWindow(game,0,0,(int)GetSystemMetrics(SM_CXSCREEN), (int)GetSystemMetrics(SM_CYSCREEN),1);
        if (GetForegroundWindow()==game)
        {
            init=0;
            SetToTop(game);
        }
        else
        {
            if (browser==NULL)
            {
                init=1;
                SetToTop(game);
            }
        }
    }
    if (browser!=NULL)
    {
        if ((HWND)(DWORD)WindowHandle!=NULL)
        {
            if (GetForegroundWindow()!=(HWND)(DWORD)WindowHandle&&GetForegroundWindow()!=browser)
            {
                init=1;
                SetToTop((HWND)(DWORD)WindowHandle);
            }
            else
            {
                init=0;
                SetToTop((HWND)(DWORD)WindowHandle);
            }
        }
        if (game!=NULL)
        {
            if (GetForegroundWindow()!=game&&GetForegroundWindow()!=browser)
            {
                init=1;
                SetToTop(game);
            }
            else
            {
                init=0;
                SetToTop(game);
            }
        }

        SetWindowLongPtr(browser,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
    }
    GetFlags(WindowHandle,game,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,0,(int)GetSystemMetrics(SM_CXSCREEN),(int)GetSystemMetrics(SM_CYSCREEN));
    }
	return 0;
}

DLL double AlwaysOnTop(double WindowHandle,HWND game,double Width, double Height)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
    if (IsChild((HWND)(DWORD)WindowHandle,FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY")))
    {
        browser=FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY");
    }
    }
    else
    {
    if (IsChild(game,FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY")))
    {
        browser=FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY");
    }
    }

    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,0);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_MINIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        if (IsIconic((HWND)(DWORD)WindowHandle)==0)
        {
            SetWindowPos((HWND)(DWORD)WindowHandle,HWND_TOPMOST,0,0,0,0,SWP_DRAWFRAME|SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE);
        }
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,0);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_MINIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        if (IsIconic(game)==0)
        {
            SetWindowPos(game,HWND_TOPMOST,0,0,0,0,SWP_DRAWFRAME|SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE);
        }
    }
    if (browser!=NULL)
    {
        SetWindowLongPtr(browser,GWL_STYLE,WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        if (IsIconic(browser)==0)
        {
            SetWindowPos(browser,HWND_TOPMOST,0,0,0,0,SWP_DRAWFRAME|SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE);
        }
    }

    GetFlags(WindowHandle,game,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_MINIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,0,Width,Height);
    EndFullscreen(WindowHandle,game);

	return 0;
}

DLL double Resizeable(double WindowHandle,HWND game,double Width, double Height)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,0);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_SIZEBOX|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop((HWND)(DWORD)WindowHandle);
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,0);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_SIZEBOX|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop(game);
    }

    GetFlags(WindowHandle,game,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_SIZEBOX|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,0,Width,Height);
    EndFullscreen(WindowHandle,game);

	return 0;
}

DLL double DialogWindow(double WindowHandle,HWND game,double Width, double Height)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,0);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop((HWND)(DWORD)WindowHandle);
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,0);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop(game);
    }

    GetFlags(WindowHandle,game,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,0,Width,Height);
    EndFullscreen(WindowHandle,game);

	return 0;
}

DLL double NoButtons(double WindowHandle,HWND game,double Width, double Height)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,0);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop((HWND)(DWORD)WindowHandle);
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,0);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop(game);
    }

    GetFlags(WindowHandle,game,WS_VISIBLE|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,0,Width,Height);
    EndFullscreen(WindowHandle,game);

	return 0;
}

DLL double ToolWindow(double WindowHandle,HWND game,double Width, double Height)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_EXSTYLE,WS_EX_TOOLWINDOW);
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop((HWND)(DWORD)WindowHandle);
    }
    else
    {
        SetWindowLongPtr(game,GWL_EXSTYLE,WS_EX_TOOLWINDOW);
        SetWindowLongPtr(game,GWL_STYLE,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        SetToTop(game);
    }

    GetFlags(WindowHandle,game,WS_VISIBLE|WS_SYSMENU|WS_BORDER|WS_CAPTION|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,WS_EX_TOOLWINDOW,Width,Height);
    EndFullscreen(WindowHandle,game);

	return 0;
}

DLL double Invisible(double WindowHandle,HWND game)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        ShowWindow((HWND)(DWORD)WindowHandle,SW_HIDE);
    }
    else
    {
        ShowWindow(game,SW_HIDE);
    }
	return 0;
}

DLL double Visible(double WindowHandle,HWND game)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        ShowWindow((HWND)(DWORD)WindowHandle,SW_SHOW);
        SetForegroundWindow((HWND)(DWORD)WindowHandle);
    }
    else
    {
        ShowWindow(game,SW_SHOW);
        SetForegroundWindow(game);
    }
	return 0;
}
