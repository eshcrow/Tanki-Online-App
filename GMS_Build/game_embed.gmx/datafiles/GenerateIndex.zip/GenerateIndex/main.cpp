#include "main.h"
#include <iostream>
#include <fstream>
#define DLL extern "C" _declspec(dllexport)
using namespace std;

DLL double WriteIndex(char *File,char *String)
{
    ofstream myfile;
    myfile.open(File);
    myfile<<String;
    myfile.close();
    return 0;
}

DLL char *ReadIndex(char *File)
{
    string String;
    char *String2;

    ifstream myfile;
    myfile.open(File);
    myfile>>String;
    myfile.close();

    String2 = strdup(String.c_str());
    return String2;
}

DLL double DeleteIndex(char *File)
{
    remove(File);
    return 0;
}
